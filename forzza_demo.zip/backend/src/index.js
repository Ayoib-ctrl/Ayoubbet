require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const DB_FILE = process.env.DB_FILE || './data/database.sqlite';
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';

// ensure data folder
if (!fs.existsSync('./data')) fs.mkdirSync('./data');
const db = new Database(DB_FILE);

// initialize tables
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT,
  email TEXT UNIQUE,
  password_hash TEXT,
  balance REAL DEFAULT 1000,
  role TEXT DEFAULT 'user',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY,
  home TEXT,
  away TEXT,
  start_time TEXT,
  odds_home REAL,
  odds_draw REAL,
  odds_away REAL,
  status TEXT DEFAULT 'upcoming',
  result TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bets (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  match_id TEXT,
  pick TEXT,
  stake REAL,
  odds REAL,
  payout REAL,
  status TEXT DEFAULT 'pending',
  placed_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('../frontend')); // serve frontend when deployed together

// helpers
function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({msg:'No token'});
  const token = auth.replace('Bearer ','');
  try{
    const payload = jwt.verify(token, JWT_SECRET);
    const row = db.prepare('SELECT id,name,email,balance,role FROM users WHERE id = ?').get(payload.id);
    if(!row) return res.status(401).json({msg:'Invalid token'});
    req.user = row;
    next();
  }catch(e){ return res.status(401).json({msg:'Invalid token'}); }
}

// register
app.post('/api/auth/register', async (req,res)=>{
  const {name,email,password} = req.body;
  if(!email || !password) return res.status(400).json({msg:'email/password required'});
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if(exists) return res.status(400).json({msg:'Email exists'});
  const hash = await bcrypt.hash(password,10);
  const id = uuidv4();
  db.prepare('INSERT INTO users(id,name,email,password_hash,balance,role) VALUES(?,?,?,?,?,?)')
    .run(id, name||'', email, hash, 1000, 'user');
  const token = jwt.sign({id}, JWT_SECRET);
  const user = db.prepare('SELECT id,name,email,balance,role FROM users WHERE id = ?').get(id);
  res.json({token, user});
});

// login
app.post('/api/auth/login', async (req,res)=>{
  const {email,password} = req.body;
  if(!email || !password) return res.status(400).json({msg:'email/password required'});
  const user = db.prepare('SELECT id,name,email,password_hash,balance,role FROM users WHERE email = ?').get(email);
  if(!user) return res.status(400).json({msg:'Invalid credentials'});
  const ok = await bcrypt.compare(password, user.password_hash);
  if(!ok) return res.status(400).json({msg:'Invalid credentials'});
  const token = jwt.sign({id:user.id}, JWT_SECRET);
  res.json({token, user:{id:user.id,name:user.name,email:user.email,balance:user.balance,role:user.role}});
});

// get current user
app.get('/api/auth/me', authMiddleware, (req,res)=> {
  res.json({user: req.user});
});

// list matches
app.get('/api/matches', (req,res)=>{
  const rows = db.prepare('SELECT * FROM matches ORDER BY start_time DESC').all();
  res.json(rows);
});

// admin add match (simple, no auth in demo) - in real use check admin role
app.post('/api/matches', (req,res)=>{
  const {home,away,start_time,odds_home,odds_draw,odds_away} = req.body;
  const id = uuidv4();
  db.prepare('INSERT INTO matches(id,home,away,start_time,odds_home,odds_draw,odds_away) VALUES(?,?,?,?,?,?)')
    .run(id,home,away,start_time||new Date().toISOString(),odds_home||2.0,odds_draw||3.0,odds_away||2.5);
  res.json({ok:true, id});
});

// admin set result
app.post('/api/matches/:id/result', (req,res)=>{
  const {id} = req.params;
  const {result} = req.body; // 'home'|'draw'|'away'
  db.prepare('UPDATE matches SET result=?, status=? WHERE id=?').run(result,'finished',id);
  // settle bets
  const bets = db.prepare('SELECT * FROM bets WHERE match_id = ? AND status = ?').all(id,'pending');
  for(const b of bets){
    let won = (b.pick === result);
    if(won){
      const payout = b.stake * b.odds;
      db.prepare('UPDATE bets SET status=?, payout=? WHERE id=?').run('won', payout, b.id);
      db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(payout, b.user_id);
    } else {
      db.prepare('UPDATE bets SET status=? WHERE id=?').run('lost', b.id);
    }
  }
  res.json({ok:true});
});

// place bet
app.post('/api/bets', authMiddleware, (req,res)=>{
  const {match_id,pick,stake} = req.body;
  if(!match_id || !pick || !stake) return res.status(400).json({msg:'params missing'});
  const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(match_id);
  if(!match) return res.status(400).json({msg:'match not found'});
  if(match.status !== 'upcoming') return res.status(400).json({msg:'match not available'});
  if(req.user.balance < stake) return res.status(400).json({msg:'Insufficient balance'});
  let odds = match.odds_draw;
  if(pick === 'home') odds = match.odds_home;
  if(pick === 'away') odds = match.odds_away;
  const id = uuidv4();
  db.prepare('INSERT INTO bets(id,user_id,match_id,pick,stake,odds,status) VALUES(?,?,?,?,?,?,?)')
    .run(id, req.user.id, match_id, pick, stake, odds, 'pending');
  db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?').run(stake, req.user.id);
  const user = db.prepare('SELECT id,name,email,balance FROM users WHERE id = ?').get(req.user.id);
  res.json({ok:true, betId:id, balance:user.balance});
});

// list user's bets
app.get('/api/bets/my', authMiddleware, (req,res)=>{
  const rows = db.prepare('SELECT * FROM bets WHERE user_id = ? ORDER BY placed_at DESC').all(req.user.id);
  res.json(rows);
});

// roulette spin
app.post('/api/roulette/spin', authMiddleware, (req,res)=>{
  const {stake, type, number} = req.body; // type: 'even','odd','number'
  if(!stake || stake<=0) return res.status(400).json({msg:'invalid stake'});
  if(req.user.balance < stake) return res.status(400).json({msg:'insufficient'});
  // outcome 0..36
  const outcome = Math.floor(Math.random()*37);
  let win=false, payout=0;
  if(type === 'even' && outcome!==0 && outcome%2===0){ win=true; payout = stake*2; }
  else if(type === 'odd' && outcome%2===1){ win=true; payout = stake*2; }
  else if(type === 'number' && number !== undefined && Number(number)===outcome){ win=true; payout = stake*35; }
  // update balance
  if(win){
    db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(payout, req.user.id);
  }
  db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?').run(stake, req.user.id);
  const user = db.prepare('SELECT id,name,email,balance FROM users WHERE id = ?').get(req.user.id);
  res.json({outcome, win, payout, balance: user.balance});
});

// simple leaderboard (top balances)
app.get('/api/leaderboard', (req,res)=>{
  const rows = db.prepare('SELECT name,balance FROM users ORDER BY balance DESC LIMIT 10').all();
  res.json(rows);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Server running on', PORT));    
