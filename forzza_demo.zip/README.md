# Forzza Demo - Ready to Deploy (Backend + Frontend)

This is a minimal demo of a **fake-money betting site** (for testing only). It includes:

- Backend: Node.js + Express + SQLite (better-sqlite3).
- Frontend: Simple static HTML that calls the backend API.
- Authentication: email/password with JWT (bcrypt).
- Features: register/login, list matches, place bet (single), roulette spin, leaderboard, admin endpoints to add matches and set results.

## Quick local run (development)

Requirements:
- Node.js 18+ installed.

Backend:
```bash
cd backend
npm install
# create data folder
mkdir -p data
node src/index.js
```

By default server runs on port 4000. The frontend is served statically from backend's static middleware at `http://localhost:4000/`.

## Deploying online (Render)

You can deploy backend on Render (or similar) as a Web Service. Render supports SQLite for simple demos.

1. Create a new Web Service on Render and connect your GitHub repo (or upload files).
2. Set the build command: `npm install`
3. Set the start command: `node src/index.js`
4. Add environment variables if desired:
   - `JWT_SECRET`
   - `PORT` (Render sets it automatically)
   - `DB_FILE` (optional - default `./data/database.sqlite`)

## Notes & Next Steps

- This demo uses a simple SQLite DB stored in the project folder (for easy deploy/testing). For production use, use Postgres or managed DB.
- Admin endpoints (create match, set result) are not protected in this demo. Protect them with admin checks before public use.
- This project is educational and uses **fake money**. Do not enable real-money operations without legal compliance.
